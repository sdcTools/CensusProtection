
# modify the path to your directory structure
# you will need the test data: "test_data_10k.csv.gz"
path <- "C:/Users/enderle/Desktop/ESTP_Course_SDC_Census_2023/00_data/"
setwd(path)


## 1. Apply the ptable-Package (STEP 1 from theory lesson)

### 1.0 Load the package
library(ptable)

### 1.1 Use the help pages and and the vignette
?pt_create_pTable

#pt_vignette() # a vignette comes along with the next release




### 1.2 Create the ptable object (two liner version)

#### 1.2.1 The two-liner version

##### 1.2.1.1 Create perturbation parameters by specifying parameters


parameters <- pt_create_pParams(D = 2, V = 1.08, js = 1, 
                                table = "cnts")
parameters


##### 1.2.1.2 Create perturbation table (ptable) using the parameter object
ptab0 <- pt_create_pTable(params = parameters)


#### 1.2.2 The one-liner version

# Wrapper function that replaces the two steps from above:
  
  
ptab1 <- create_cnt_ptable(D = 2, V = 1.08, js = 1)


# The two objects `ptab0` and `ptab1` are identical.



### 1.3 Look at some content of the ptable object

#### 1.3.1 The transition matrix

ptab1@pMatrix


# You can also get a graphical view of the transition matrix:
plot(ptab1, type = "t")


#### 1.3.2 The perturbation table (i.e. the ptable itself)

ptab1@pTable


# You can also get a graphical view of the perturbation table which is called perturbation panel:

plot(ptab1, type = "p")


### 1.4 Check the ptable

# The ptable-package is very flexible and offers many possibilities to design your very own and specific ptable.
# Hence, you will have to check what you have designed. Remember our design: maximum noise D=4 and variance V=1.08 and js=1 (no 1's).

#### 1.4.1 Check the designed ptable

ptab1@empResults



#### 1.4.2 Use the distribution plot

# This is another possibility to visualize the ptable (besides the perturbation panel):

plot(ptab1, type = "d")


# Indeed, the variance for frequency counts `i=3` is too small. (Hint: if `iter` is larger than 1, the function tried to correct for the *wrong* variance). 
# However, you now have to either modify your design or adjust the settings of the computation (i.e. change some arguments).

### 1.5 Adjust the settings

# Give up the monotony restriction
ptab1 <- create_cnt_ptable(D = 2, V = 1.08, js = 1, mono = F)
# alternatively use
ptab1 <- create_cnt_ptable(D = 2, V = 1.08, js = 1, mono = c(T,T,F,T))



# Another possibility is to adjust the optimization (change the argument `optim = ...`; default is `1`). See exercise ...


### 1.6 Check the ptable again

plot(ptab1, type = "d")
# or
ptab1@empResults

### 1.7 Modify ptable

#To reduce risks you can rearrange the intervals (i.e. splitting large intervals # into small intervals and reorder the intervals)

ptab_mod <- modify_cnt_ptable(ptab1, threshold = 0.2, seed=123)

# Compare the ptables:
ptab_mod@pTable
ptab1@pTable

# From now on, you could use `ptab_mod` instead of `ptab1`. Anyway, in this course we well use `ptab1`, because it is easier to demonstrate the method.


## 2. Apply the cellKey-Package (STEPS 2 to 5 from theory lesson)


### 2.0 Load the package


library(cellKey)



### 2.1 Use the help pages and the vignette

?cellkey_pkg
#ck_vignette()



### 2.2 Import the (micro) data
dat <- fread("test_data_10k.csv.gz")

# Two issues:
# > Data don't have to be numeric of type 'integer' (in contrary to the TRS package): character or numeric (integer, decimals)
# > Hierarchy variables: we don't need NUTS1, NUTS2, NUTS3 if we have LAU2.


### 2.3 Create/Draw the record keys (STEP 2 from theory lesson)

dat$rkey <- ck_generate_rkeys(dat = dat, seed = 123)

# Alternatively you can apply any common random generator 
# (f.i. in R: `runif(n = nrow(dat), min = 0 , max = 1)`).



### 2.4 Define the required inputs (dimensions and hierarchies)

# We will use the R-Package `sdcHierarchies` (which will be loaded automatically if you load the `cellKey`-package).


#### 2.4.1 Enter the variable codes/outcomes manually


d_sex <- 
  hier_create(
    nodes = c("1","2"), 
    root = "Total"
  ); 

d_sex

hier_display(d_sex)


#### 2.4.2 Generate the variable outcomes data-driven



# 'read' the data
coc.m_cat <- unique(as.character(dat$COC.M))

d_coc.m <- 
  hier_compute(
    inp = coc.m_cat, # inp = c("1","21","221", ...) 
    dim_spec = c(1,1,1), 
    root = "Total",
    method = "len"
  ); 

hier_display(d_coc.m)




### 2.5 Define the setup
tab <- ck_setup(
  x = dat,
  rkey = "rkey",
  dims = list(SEX = d_sex, COC.M = d_coc.m)
)

# show some information about this table instance
tab



### 2.6 Check the dimensions or hierarchy


# information about the hierarchies
tab$hierarchy_info()



### 2.7 Prepare the perturbation (include the ptable)

#extract the ptable itself from the object 'ptab1'
ptab_input <- ck_params_cnts(ptab = ptab1)

# `ptab_input` is not the complete ptable-object any longer.
ptab_input

# use this ptable for 'total'
tab$params_cnts_set(val = ptab_input, v = "total")


# In this context, `"total"` means that we are producing the complete table according to the variable 
# definition (i.e. what we have set via the argument `dims` in the function `ck_setup(... , dims= ...`). (Additional to `total`, we could also specify a filter. See help pages for more details.)


### 2.8 Apply the perturbation (STEP 5 from theory lesson)

# Step 5 is the so-called **LOOKUP** step.
# perturb the table
tab$perturb(v = "total")



### 2.9 The perturbed table

# return results
tab$freqtab(v = "total")




### 2.10 Detailed view of the modifications for perturbed count variables

tab$mod_cnts()
 

### 2.11 Overall summary

# - Distribution statistics of perturbations

# - There are three utility measures:
#   > d1: absolute distance between original and perturbed values
#   > d2: relative absolute distance between original and perturbed values
#   > d3: absolute distance between square-roots of original and perturbed values

tab$summary()



### 2.12 Further measures

# utility measures for a count variable
tab$measures_cnts(v = "total")

# false zero: number of cells that were perturbed to zero
# false non-zero: number of cells that were initially zero but have been perturbed to a number different from zero
# exclude_zeros: were empty cells exluded from computation or not


### 2.13 Export your perturbed results

# Write your results to a csv-file (the extension *.csv* is automatically added to the path)

tab$freqtab(v = c("total"), path = "outtab.csv")





## Appendix: If you do the perturbation in Tau-Argus

### A. Design and export the ptable (see Section 1)
ptab1 <- create_cnt_ptable(D = 2, V = 1.08, js = 1, mono = c(T,T,F,T))
pt_export(ptab1, file = "ptab1", SDCtool = "TauArgus")



### B. Export the data set (see Section 2)
dat <- fread("test_data_10k.csv.gz")
dat$rkey <- ck_generate_rkeys(dat = dat, seed = 123)
#runif()
fwrite(dat, file="test_data_10k_rkey.csv", sep=";")





