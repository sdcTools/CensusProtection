

#########################################################
## Day 2 - Exercises CKM in R                           #
## ESTP Course on SDC Methods and Tools for Census 2021 #
#########################################################


# Set the working directory
setwd("C:/Users/enderle/Desktop/ESTP_Course_SDC_Census_2023/03_exercises/")

# Load the packages
library(data.table)
library(cellKey)
library(ptable)

# Load the data
dat <- fread("test_data_10k.csv.gz")




## Exercises 1 to 3: ptable-Package ##
## ================================ ##


## (1) Use the ptable object 'ptab1' we produced in the demonstration lesson and answer some questions.

ptab1 <- create_cnt_ptable(D = 2, V = 1.08, js = 1, mono = c(T,T,F,T))

# To answer the following questions (a) to (e) try to remember which part of `ptab1` could be useful. You could also use
# a graphic to answer the question.


## Question: What will be the noise and the frequency count after perturbation if you assume ...
# (1a) ... a frequency count of 1 and a cell-key of 0.2513548301578? 
# (1b) ... a frequency count of 1 and a cell-key of 0.97333333? 
# (1c) ... a frequency count of 970 and a cell-key of 0.70548315646?
# (1d) ... a frequency count of 3 and a cell-key of 1.0000000000?
# (1e) ... a frequency count of 0 and a cell-key of 0.5012415871?

# Hint: Either use the graphical view 'plot(object, type='p')' or the ptable 
# itself 'object@pTable' to answer the questions.

ptab1@pTable
plot(ptab1, type="p")




# (1f) Modify the ptable and split all intervals larger than 0.1. Does that affect you interpretation from above?



## (2) Please design a ptable object 'ptab2' with the following specifications: a maximum noise of D=8, 
## a high variance of V=3 and a probability of 60%, that frequencies won't be changed.

# Hint 1: Have a look at the help page '?pt_create_pTable'. There you can find the argument you must apply to
# set the probability that frequency counts won't be changed.

# Hint2: If you get warnings or the conditions aren't met, you may use the argument 'optim = ...'.
# (Default is 'optim = 1'. An alternative is '4'.)

ptab2 <- create_cnt_ptable(D = 8, V = 3, pstay = 0.6)

?pt_create_pTable


# Useful code:  - plot(ptab2, type = "t")
#               - ptab2@empResults

plot(ptab2, type = "d")
ptab2@empResults

ptab2 <- create_cnt_ptable(D = 8, V = 3, pstay = 0.6, optim = 4)
ptab2@empResults

ptab2 <- create_cnt_ptable(D = 8, V = 3, pstay = c(0.6,0.6,0.6,0.6,0.6,0.6,0.6), optim = 4)

pt_create_pParams(D = 8, V = 3, 
                  table = "cnts")


## (3) [Advanced] Design a further ptable object 'ptab3' with D=8, V=3 but different probabilities for original
## frequency counts: 50% for small frequency counts and 30% for the last frequency count (the
## symmetry case).

# Remember: The arguments 'D', 'V' and 'js' are scalar input arguments. 'pstay', 'optim' and 'mono' are
# either scalar or vector input arguments.

# Remember: The amount of different frequency counts 'i' in a ptable depends on 'D' (and 'js' which is not used
# in this exercise). The ptable entries of the last frequency count 'i_max' (symmetry case) will be applied
# for all frequencies equal or larger than 'i_max' (In the demonstration this morning, 'i_max' was 4. 
# Thus, all frequencies in a table with values larger than 4 will be perturbed the same "way" like a 4).

# Hint: Use the result from exercise (2) and extend it.

ptab3 <- ...




## Exercises 4 to 9: cellKey ##
## ========================= ##


## (4) Please rerun the perturbation from the demonstration lesson and answer some questions.

# record keys
dat$rkey <- ck_generate_rkeys(dat = dat, seed = 123)


# dimensions and hierarchy
d_sex <- 
  hier_create(
    nodes = c("1","2"), 
    root = "Total"
  ); 

coc.m_cat <- unique(as.character(dat$COC.M))

?hier_compute

d_coc.m <- 
  hier_compute(
    inp = coc.m_cat, # inp = c("1","21","221", ...) 
    dim_spec = c(1,1,1), 
    root = "Total",
    method = "len"
  ); 


# define the table
tab <- ck_setup(
  x = dat,
  rkey = "rkey",
  dims = list(SEX = d_sex, COC.M = d_coc.m)
)

# prepare and perturb the table
ptab_input <- ck_params_cnts(ptab = ptab1)
tab$params_cnts_set(val = ptab_input, v = "total")
tab$perturb(v = "total")





## (4a) What is the maximum relative absolute distance between original and perturbed values? Give an
## interpretation of the value and search the table cell (give the defintion of the table cell).

tab$summary()

## (4b) There is exactly one table cell, that has been changed by `+2`. Which one (give the definition of the table cell)?





## (5) Now, extend the two-dimensional table by a geographical variable.

# (5a) Create the variable hierarchy/dimension for NUTS3. NUTS3 has 3 levels each of length 1. Please use
# 'hier_compute(...)' (similar to the hierarchy of the variable COC.M).

head(dat$NUTS3)

nuts3 <- unique(as.character(dat$NUTS3))

d_nuts3 <- hier_compute(inp = nuts3,
             dim_spec = c(1,1,1),
             root="TOTAL",
             method = "len")
hier_display(d_nuts3)


# (5b) Update the following setup using the hierarchy of NUTS3 you created in (5a) and assign it to 
# the object 'tab5'.



# Remark: The list for the argument 'dims = ...' must be entered case-sensitively!

tab5 <- ck_setup(x = dat, rkey="rkey",
                 dims = list(SEX = d_sex, COC.M = d_coc.m, NUTS3 = d_nuts3) )


# (5c) Question: How many cells does the newly generated 3-dimensional table have?

tab5

# (5d) Apply the perturbation using the ptable 'ptab2'. How many 1's are in original table and how many 1's 
# have been changed by +8 (try to explain)?


# (5e) How many (absolute or relative) cells are still original (i.e. remain unchanged) after perturbation? 

tab5$freqtab(v="total")

# (5f) How large are the three mean distances (utility measures) when you take original zero counts
# into account:
# - d1: absolute distance between original and perturbed values
# - d2: relative absolute distance between original and perturbed values
# - d3: absolute distance between square-roots of original and perturbed values



## (6) Compare different perturbations.

## (6a) Produce the table from exercise 5 again and assign it to the object 'tab6'.
tab6 <- ck_setup(...)


# Hint: Don't copy the object like: tab6 <- tab5 (!! doesn't work)

# Remark: If you try to perturb a table and receive the message 
# "--> Variable "total" was already perturbed: parameters are not updated." then you have to rerun
# the 'ck_setup(..)' step. you can't perturb the object twice.



## (6b) Perturb 'tab6' by the following ptable:

ptab6 <- create_cnt_ptable(D = 8, V = 2, pstay = 0.6, optim=4)

 


## (6c)  Compare the measure "relative absolute distance" between the two different 
## perturbations in (5) and (6). Which perturbation comes along with a lower information loss?



## (6d) [Advanced] Compare the distributions of the two ptables `ptab2` (which was used to perturb `tab5`)
## and `ptab6` (which was used to perturb `tab6`) and try to explain the result in (6c).



## (7) [Advanced]

## (7a) Use `dat` and create a household data set (with `HID`, `LAU2`, size of the household `Size` and mean age using `AGE.H`). Then, assign a record key to each household. 



## (7b) How many households do we have? What will be the cell-key for this total number (don't use the cellKey-package; compute it manually) 
## and what would be the noise if we use `ptab1` (manual lookup using the graph or look into the ptable)?

ptab1 <- create_cnt_ptable(D = 2, V = 1.08, js = 1, mono = c(T,T,F,T))







### Exercise (8) [Advanced]

# Create a one-dimensional table with the hierarchical variable NUTS3 and apply a filter.

## (8a) Create a table object 'tab8' with a filter (argument 'countvars = ...'). The filter shall only count 
## females (variable 'sex == 2'). (i.e. call the filter ). Use the help page '?cellkey_pkg' to define the argument 'countvars'.

tab8 <-




## (8b) Perturb the table using the new countvar and ptable 'ptab1'.

  

## Exercise (9) [Advanced] 

## (9a) Compare the distributions of the two following ptables.

ptab91 <- create_cnt_ptable(D = 5, V = 0.5, optim=4)
ptab92 <- create_cnt_ptable(D = 5, V = 2, optim=4)

## What is the main difference between the distributions (look at the graph)?
  


## (9b) What would you expect: Which ptable has a lower loss of information? Perturb the table you have designed in (8) twice and perturb the tables with the two ptables.

tab91 <- ...
tab92 <- ...

